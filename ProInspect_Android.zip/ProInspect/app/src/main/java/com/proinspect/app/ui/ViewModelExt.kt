package com.proinspect.app.ui
// deleteReport is now a direct method on InspectionViewModel
