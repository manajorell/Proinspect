package com.proinspect.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.proinspect.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class InspectionViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = InspectionRepository.getInstance(application)
    val allReports = repo.allReports.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Current report state
    private val _currentReportId = MutableStateFlow<Long?>(null)
    val currentReportId: StateFlow<Long?> = _currentReportId

    private val _currentReport = MutableStateFlow<Report?>(null)
    val currentReport: StateFlow<Report?> = _currentReport

    private val _items = MutableStateFlow<Map<String, InspectionItem>>(emptyMap())
    val items: StateFlow<Map<String, InspectionItem>> = _items

    private val _photos = MutableStateFlow<List<InspectionPhoto>>(emptyList())
    val photos: StateFlow<List<InspectionPhoto>> = _photos

    // Temp photo URI for camera
    private var tempPhotoUri: Uri? = null
    private var tempPhotoPath: String? = null
    private var tempPhotoSection: String = ""
    private var tempPhotoItemId: String? = null

    fun loadReport(reportId: Long) {
        _currentReportId.value = reportId
        viewModelScope.launch {
            _currentReport.value = repo.getReport(reportId)
            // Load items into map
            repo.getItemsForReport(reportId)
                .collect { list ->
                    _items.value = list.associateBy { it.itemId }
                }
        }
        viewModelScope.launch {
            repo.getPhotosForReport(reportId)
                .collect { _photos.value = it }
        }
    }

    fun createNewReport(): Long {
        var newId = 0L
        viewModelScope.launch {
            val report = Report(
                reportNumber = "RPT-${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())}-${(1000..9999).random()}",
                inspectionDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            )
            newId = repo.createReport(report)
            loadReport(newId)
        }
        return newId
    }

    fun saveReport(report: Report) {
        viewModelScope.launch {
            repo.updateReport(report.copy(updatedAt = System.currentTimeMillis()))
            _currentReport.value = report
        }
    }

    fun setItemRating(itemId: String, section: String, rating: Rating) {
        val reportId = _currentReportId.value ?: return
        viewModelScope.launch {
            val existing = _items.value[itemId]
            val item = existing?.copy(rating = rating) ?: InspectionItem(
                itemId = itemId, reportId = reportId, rating = rating, section = section
            )
            repo.saveItem(item)
        }
    }

    fun setItemNarrative(itemId: String, section: String, narrative: String) {
        val reportId = _currentReportId.value ?: return
        viewModelScope.launch {
            val existing = _items.value[itemId]
            val item = existing?.copy(narrative = narrative) ?: InspectionItem(
                itemId = itemId, reportId = reportId, narrative = narrative, section = section
            )
            repo.saveItem(item)
        }
    }

    fun prepareCameraUri(context: Context, section: String, itemId: String?): Uri {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val file = File.createTempFile("IMG_${timeStamp}_", ".jpg", storageDir)
        tempPhotoPath = file.absolutePath
        tempPhotoSection = section
        tempPhotoItemId = itemId
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        tempPhotoUri = uri
        return uri
    }

    fun onPhotoCaptured(success: Boolean) {
        if (!success) return
        val reportId = _currentReportId.value ?: return
        val path = tempPhotoPath ?: return
        viewModelScope.launch {
            repo.addPhoto(
                InspectionPhoto(
                    reportId = reportId,
                    itemId = tempPhotoItemId,
                    section = tempPhotoSection,
                    filePath = path
                )
            )
        }
    }

    fun addPhotoFromGallery(context: Context, uri: Uri, section: String, itemId: String?) {
        val reportId = _currentReportId.value ?: return
        viewModelScope.launch {
            // Copy to app storage
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            val dest = File(storageDir, "IMG_${timeStamp}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            }
            repo.addPhoto(
                InspectionPhoto(
                    reportId = reportId,
                    itemId = itemId,
                    section = section,
                    filePath = dest.absolutePath
                )
            )
        }
    }

    fun deletePhoto(photoId: Long) {
        viewModelScope.launch { repo.deletePhoto(photoId) }
    }

    fun photosForItem(itemId: String) = _photos.value.filter { it.itemId == itemId }
    fun photosForSection(section: String) = _photos.value.filter { it.section == section && it.itemId == null }

    fun deleteReport(report: com.proinspect.app.data.Report) {
        viewModelScope.launch { repo.deleteReport(report) }
    }

}
