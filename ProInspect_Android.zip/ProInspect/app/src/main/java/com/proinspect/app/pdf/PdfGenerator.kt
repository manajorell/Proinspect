package com.proinspect.app.pdf

import android.content.Context
import android.graphics.BitmapFactory
import android.os.Environment
import com.itextpdf.text.*
import com.itextpdf.text.pdf.*
import com.proinspect.app.data.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfGenerator {

    // Colors
    private val colorNavy   = BaseColor(26, 39, 68)
    private val colorGold   = BaseColor(201, 151, 58)
    private val colorRed    = BaseColor(220, 38, 38)
    private val colorOrange = BaseColor(234, 88, 12)
    private val colorYellow = BaseColor(202, 138, 4)
    private val colorGreen  = BaseColor(22, 163, 74)
    private val colorGray   = BaseColor(107, 114, 128)
    private val colorLightGray = BaseColor(243, 244, 246)
    private val colorWhite  = BaseColor.WHITE

    // Fonts
    private val fontTitle   = Font(Font.FontFamily.HELVETICA, 22f, Font.BOLD,   colorNavy)
    private val fontH2      = Font(Font.FontFamily.HELVETICA, 14f, Font.BOLD,   colorNavy)
    private val fontH3      = Font(Font.FontFamily.HELVETICA, 11f, Font.BOLD,   colorNavy)
    private val fontBody    = Font(Font.FontFamily.HELVETICA, 10f, Font.NORMAL, BaseColor(31, 41, 55))
    private val fontSmall   = Font(Font.FontFamily.HELVETICA, 8f,  Font.NORMAL, colorGray)
    private val fontGold    = Font(Font.FontFamily.HELVETICA, 10f, Font.BOLD,   colorGold)
    private val fontWhite   = Font(Font.FontFamily.HELVETICA, 11f, Font.BOLD,   colorWhite)
    private val fontWhiteSm = Font(Font.FontFamily.HELVETICA, 9f,  Font.NORMAL, colorWhite)

    private fun ratingBaseColor(r: Rating) = when (r) {
        Rating.SAFETY    -> colorRed
        Rating.MAJOR     -> colorOrange
        Rating.MONITOR   -> colorYellow
        Rating.GOOD      -> colorGreen
        Rating.NOT_RATED -> colorGray
    }

    suspend fun generate(
        context: Context,
        report: Report,
        items: List<InspectionItem>,
        photos: List<InspectionPhoto>
    ): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            ?: context.filesDir
        val file = File(dir, "ProInspect_Report_${timeStamp}.pdf")

        val document = Document(PageSize.LETTER, 40f, 40f, 50f, 50f)
        val writer = PdfWriter.getInstance(document, FileOutputStream(file))
        writer.pageEvent = PageNumberEvent()
        document.open()

        addCoverPage(document, report, items)
        addSummaryStats(document, items)
        addPriorityFindings(document, items, photos)
        addSectionDetails(document, report, items, photos)
        addDisclaimer(document, report)

        document.close()
        return file
    }

    // ── Cover Page ────────────────────────────────────────────────────────────

    private fun addCoverPage(doc: Document, report: Report, items: List<InspectionItem>) {
        // Dark header band
        val headerTable = PdfPTable(1).apply { widthPercentage = 100f; spacingAfter = 20f }
        val headerCell = PdfPCell().apply {
            backgroundColor = colorNavy
            border = Rectangle.NO_BORDER
            paddingTop = 30f; paddingBottom = 30f; paddingLeft = 20f; paddingRight = 20f
        }
        headerCell.addElement(Paragraph("ProInspect", Font(Font.FontFamily.HELVETICA, 28f, Font.BOLD, colorGold)))
        headerCell.addElement(Paragraph("HOME INSPECTION REPORT", Font(Font.FontFamily.HELVETICA, 11f, Font.NORMAL, colorWhite)))
        headerCell.addElement(Paragraph(" "))
        headerCell.addElement(Paragraph(report.propertyAddress.ifBlank { "Property Address Not Entered" },
            Font(Font.FontFamily.HELVETICA, 16f, Font.BOLD, colorWhite)))
        if (report.propertyCity.isNotBlank())
            headerCell.addElement(Paragraph(report.propertyCity, Font(Font.FontFamily.HELVETICA, 12f, Font.NORMAL, colorWhite.apply { })))
        headerTable.addCell(headerCell)
        doc.add(headerTable)

        // Property details grid
        val infoTable = PdfPTable(2).apply { widthPercentage = 100f; spacingAfter = 16f; setWidths(floatArrayOf(1f, 1f)) }
        fun infoCell(label: String, value: String): PdfPCell {
            val cell = PdfPCell().apply {
                border = Rectangle.NO_BORDER
                backgroundColor = colorLightGray
                paddingAll = 10f
            }
            cell.addElement(Paragraph(label, fontSmall))
            cell.addElement(Paragraph(value.ifBlank { "—" }, fontH3))
            return cell
        }
        infoTable.addCell(infoCell("CLIENT", report.clientName))
        infoTable.addCell(infoCell("INSPECTION DATE", report.inspectionDate))
        infoTable.addCell(infoCell("INSPECTOR", report.inspectorName))
        infoTable.addCell(infoCell("CERTIFICATION #", report.inspectorCert))
        infoTable.addCell(infoCell("COMPANY", report.inspectorCompany))
        infoTable.addCell(infoCell("REPORT NUMBER", report.reportNumber))
        infoTable.addCell(infoCell("YEAR BUILT", report.yearBuilt))
        infoTable.addCell(infoCell("SQUARE FOOTAGE", report.squareFootage))
        doc.add(infoTable)

        doc.add(Chunk(LineSeparator(1f, 100f, colorGold, Element.ALIGN_CENTER, -2f)))
        doc.newPage()
    }

    // ── Summary Stats ─────────────────────────────────────────────────────────

    private fun addSummaryStats(doc: Document, items: List<InspectionItem>) {
        doc.add(Paragraph("Executive Summary", fontTitle).apply { spacingAfter = 12f })
        val counts = Rating.values().associateWith { r -> items.count { it.rating == r } }

        val statsTable = PdfPTable(5).apply { widthPercentage = 100f; spacingAfter = 20f }
        fun statCell(label: String, count: Int, color: BaseColor) {
            val cell = PdfPCell().apply {
                border = Rectangle.TOP
                borderColorTop = color
                borderWidthTop = 4f
                backgroundColor = colorWhite
                paddingAll = 14f
                horizontalAlignment = Element.ALIGN_CENTER
            }
            cell.addElement(Paragraph(count.toString(), Font(Font.FontFamily.HELVETICA, 28f, Font.BOLD, color)).apply { alignment = Element.ALIGN_CENTER })
            cell.addElement(Paragraph(label, Font(Font.FontFamily.HELVETICA, 8f, Font.BOLD, colorGray)).apply { alignment = Element.ALIGN_CENTER })
            statsTable.addCell(cell)
        }
        statCell("🚨 SAFETY",  counts[Rating.SAFETY]   ?: 0, colorRed)
        statCell("⚠ MAJOR",   counts[Rating.MAJOR]    ?: 0, colorOrange)
        statCell("👁 MONITOR", counts[Rating.MONITOR]  ?: 0, colorYellow)
        statCell("✓ GOOD",    counts[Rating.GOOD]     ?: 0, colorGreen)
        statCell("○ N/RATED", counts[Rating.NOT_RATED] ?: 0, colorGray)
        doc.add(statsTable)
    }

    // ── Priority Findings ─────────────────────────────────────────────────────

    private fun addPriorityFindings(doc: Document, items: List<InspectionItem>, photos: List<InspectionPhoto>) {
        val findings = items.filter { it.rating == Rating.SAFETY || it.rating == Rating.MAJOR || it.rating == Rating.MONITOR }
            .sortedWith(compareBy { when (it.rating) { Rating.SAFETY -> 0; Rating.MAJOR -> 1; else -> 2 } })
        if (findings.isEmpty()) return

        doc.add(Paragraph("Priority Findings", fontH2).apply { spacingBefore = 10f; spacingAfter = 10f })

        findings.forEach { item ->
            val allItems = InspectionSections.allItems()
            val checklistItem = allItems.find { it.id == item.itemId }
            val color = ratingBaseColor(item.rating)

            val table = PdfPTable(1).apply { widthPercentage = 100f; spacingAfter = 8f }
            val cell = PdfPCell().apply {
                border = Rectangle.LEFT
                borderColorLeft = color
                borderWidthLeft = 4f
                paddingAll = 10f
                backgroundColor = colorWhite
            }
            cell.addElement(Paragraph(item.section.replaceFirstChar { it.uppercase() } + " › " + (checklistItem?.title ?: item.itemId),
                Font(Font.FontFamily.HELVETICA, 10f, Font.BOLD, color)))
            if (item.narrative.isNotBlank())
                cell.addElement(Paragraph(item.narrative, fontBody))

            // Item photos (max 3)
            val itemPhotos = photos.filter { it.itemId == item.itemId }.take(3)
            if (itemPhotos.isNotEmpty()) {
                val photoRow = PdfPTable(itemPhotos.size).apply { widthPercentage = 60f; spacingBefore = 6f }
                itemPhotos.forEach { photo ->
                    try {
                        val bmp = BitmapFactory.decodeFile(photo.filePath)
                        if (bmp != null) {
                            val stream = java.io.ByteArrayOutputStream()
                            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, stream)
                            val img = Image.getInstance(stream.toByteArray())
                            img.scaleToFit(120f, 90f)
                            val pc = PdfPCell(img).apply { border = Rectangle.NO_BORDER; paddingRight = 4f }
                            photoRow.addCell(pc)
                        }
                    } catch (e: Exception) { /* skip bad photo */ }
                }
                cell.addElement(photoRow)
            }
            table.addCell(cell)
            doc.add(table)
        }
        doc.newPage()
    }

    // ── Section Details ───────────────────────────────────────────────────────

    private fun addSectionDetails(doc: Document, report: Report, items: List<InspectionItem>, photos: List<InspectionPhoto>) {
        doc.add(Paragraph("Full Inspection Details", fontH2).apply { spacingAfter = 14f })

        val sectionNarratives = mapOf(
            "roofing" to report.roofingNarrative, "exterior" to report.exteriorNarrative,
            "structure" to report.structureNarrative, "electrical" to report.electricalNarrative,
            "hvac" to report.hvacNarrative, "plumbing" to report.plumbingNarrative,
            "interior" to report.interiorNarrative, "insulation" to report.insulationNarrative,
            "garage" to report.garageNarrative
        )

        InspectionSections.sections.forEach { section ->
            val sectionItems = InspectionSections.items[section] ?: return@forEach
            val sectionName = InspectionSections.sectionNames[section] ?: section

            // Section header band
            val hdrTable = PdfPTable(1).apply { widthPercentage = 100f; spacingAfter = 6f; spacingBefore = 14f }
            val hdrCell = PdfPCell(Phrase(sectionName.uppercase(), fontWhite)).apply {
                backgroundColor = colorNavy
                paddingAll = 8f; border = Rectangle.NO_BORDER
            }
            hdrTable.addCell(hdrCell)
            doc.add(hdrTable)

            // Checklist table
            val tbl = PdfPTable(3).apply { widthPercentage = 100f; setWidths(floatArrayOf(4f, 1f, 3f)); spacingAfter = 8f }
            fun hdr(text: String) = PdfPCell(Phrase(text, fontSmall)).apply {
                backgroundColor = colorLightGray; paddingAll = 6f; border = Rectangle.BOTTOM
            }
            tbl.addCell(hdr("ITEM")); tbl.addCell(hdr("RATING")); tbl.addCell(hdr("NOTES"))

            sectionItems.forEach { ci ->
                val found = items.find { it.itemId == ci.id }
                val rating = found?.rating ?: Rating.NOT_RATED
                val color = ratingBaseColor(rating)

                tbl.addCell(PdfPCell(Phrase(ci.title, fontBody)).apply { paddingAll = 6f; border = Rectangle.BOTTOM })
                tbl.addCell(PdfPCell(Phrase(rating.short, Font(Font.FontFamily.HELVETICA, 9f, Font.BOLD, color))).apply {
                    paddingAll = 6f; border = Rectangle.BOTTOM; horizontalAlignment = Element.ALIGN_CENTER
                })
                tbl.addCell(PdfPCell(Phrase(found?.narrative?.ifBlank { "—" } ?: "—", fontSmall)).apply { paddingAll = 6f; border = Rectangle.BOTTOM })
            }
            doc.add(tbl)

            // Section narrative
            val narrative = sectionNarratives[section]
            if (!narrative.isNullOrBlank()) {
                val nBox = PdfPTable(1).apply { widthPercentage = 100f; spacingAfter = 8f }
                val nCell = PdfPCell().apply {
                    border = Rectangle.BOX; borderColor = colorGold; paddingAll = 10f
                    backgroundColor = BaseColor(253, 249, 242)
                }
                nCell.addElement(Paragraph("Inspector Narrative", fontGold))
                nCell.addElement(Paragraph(narrative, fontBody))
                nBox.addCell(nCell)
                doc.add(nBox)
            }

            // Section photos (max 4 per section)
            val sectionPhotos = photos.filter { it.section == section && it.itemId == null }.take(4)
            if (sectionPhotos.isNotEmpty()) {
                val cols = minOf(sectionPhotos.size, 4)
                val photoTable = PdfPTable(cols).apply { widthPercentage = 100f; spacingAfter = 10f }
                sectionPhotos.forEach { photo ->
                    try {
                        val bmp = BitmapFactory.decodeFile(photo.filePath)
                        if (bmp != null) {
                            val stream = java.io.ByteArrayOutputStream()
                            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, stream)
                            val img = Image.getInstance(stream.toByteArray())
                            img.scaleToFit(130f, 100f)
                            val pc = PdfPCell(img).apply { border = Rectangle.NO_BORDER; paddingAll = 3f; horizontalAlignment = Element.ALIGN_CENTER }
                            photoTable.addCell(pc)
                        }
                    } catch (e: Exception) {}
                }
                // Fill empty cells if needed
                repeat(cols - sectionPhotos.size) {
                    photoTable.addCell(PdfPCell().apply { border = Rectangle.NO_BORDER })
                }
                doc.add(photoTable)
            }
        }
    }

    // ── Disclaimer ────────────────────────────────────────────────────────────

    private fun addDisclaimer(doc: Document, report: Report) {
        doc.newPage()
        doc.add(Paragraph("Scope & Limitations", fontH2).apply { spacingAfter = 10f })
        val text = buildString {
            if (report.limitations.isNotBlank()) { append(report.limitations); append("\n\n") }
            append("This report was prepared in accordance with InterNACHI® Standards of Practice. ")
            append("The inspection is a visual examination of the readily accessible areas of the home ")
            append("and is not technically exhaustive. The inspector makes no representations regarding ")
            append("items that were not inspected due to limited access, concealment, or conditions present ")
            append("at the time of inspection.\n\n")
            append("Recommend evaluation and repair by licensed contractors for all items rated Major Concern or Safety Issue prior to closing.\n\n")
            append("Inspector: ${report.inspectorName}  |  Cert: ${report.inspectorCert}  |  Date: ${report.inspectionDate}")
        }
        doc.add(Paragraph(text, fontBody))
        doc.add(Chunk(LineSeparator(1f, 100f, colorGold, Element.ALIGN_CENTER, -2f)))
        doc.add(Paragraph("\nPerformed in accordance with InterNACHI® Standards of Practice  |  www.nachi.org",
            Font(Font.FontFamily.HELVETICA, 9f, Font.ITALIC, colorGray)).apply { alignment = Element.ALIGN_CENTER })
    }

    // ── Page Numbers ──────────────────────────────────────────────────────────

    class PageNumberEvent : PdfPageEventHelper() {
        override fun onEndPage(writer: PdfWriter, document: Document) {
            val cb = writer.directContent
            val font = Font(Font.FontFamily.HELVETICA, 8f, Font.NORMAL, BaseColor(156, 163, 175))
            val phrase = Phrase("Page ${document.pageNumber}  |  ProInspect — InterNACHI Report", font)
            ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, phrase,
                (document.left() + document.right()) / 2, document.bottom() - 10, 0f)
        }
    }
}
