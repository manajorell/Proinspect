package com.proinspect.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.proinspect.app.data.InspectionSections
import com.proinspect.app.ui.*

class MainActivity : ComponentActivity() {

    private val viewModel: InspectionViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProInspectTheme {
                ProInspectApp(viewModel)
            }
        }
    }
}

@Composable
fun ProInspectApp(viewModel: InspectionViewModel) {
    val navController = rememberNavController()
    val reports by viewModel.allReports.collectAsState()
    var currentTab by remember { mutableIntStateOf(0) }

    NavHost(navController = navController, startDestination = "reports") {

        // ── Reports List ──────────────────────────────────────────────────────
        composable("reports") {
            ReportsListScreen(
                reports = reports,
                onNewReport = {
                    val id = viewModel.createNewReport()
                    // Wait a tick for DB to return id via StateFlow, then navigate
                    navController.navigate("report")
                    currentTab = 0
                },
                onOpenReport = { id ->
                    viewModel.loadReport(id)
                    navController.navigate("report")
                    currentTab = 0
                },
                onDeleteReport = { viewModel.deleteReport(it) }
            )
        }

        // ── Report (tabbed) ───────────────────────────────────────────────────
        composable("report") {
            val report by viewModel.currentReport.collectAsState()
            val tabSections = listOf("info") + InspectionSections.sections + listOf("summary")

            ReportScreen(
                report = report,
                currentTab = currentTab,
                onTabChange = { currentTab = it },
                onBack = { navController.popBackStack() }
            ) {
                when (val section = tabSections.getOrNull(currentTab) ?: "info") {
                    "info"    -> PropertyInfoScreen(viewModel)
                    "summary" -> SummaryScreen(viewModel)
                    else      -> InspectionSectionScreen(section = section, viewModel = viewModel)
                }
            }
        }
    }
}
